

#ifndef CHANGECLK_H
#define CHANGECLK_H

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif

void newClk(unsigned int); // Function to change clock frequency

#endif /* CHANGECLK_H */
